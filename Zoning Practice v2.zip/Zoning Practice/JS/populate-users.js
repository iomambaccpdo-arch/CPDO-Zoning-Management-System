// Populate dropdowns in new-document.html from users in localStorage
// Received By, Assisted By, OIC: names; Routed To: emails

document.addEventListener('DOMContentLoaded', function() {
  const users = JSON.parse(localStorage.getItem('users')) || [];
  // Get dropdowns
  const receivedSelect = document.getElementById('receivedSelect');
  const assistedSelect = document.getElementById('assistedSelect');
  const oicSelect = document.getElementById('oicSelect');
  const routedSelect = document.getElementById('routedSelect');

  // Helper: clear and add default option
  function resetSelect(select, label) {
    if (!select) return;
    select.innerHTML = '';
    const opt = document.createElement('option');
    opt.value = '';
    opt.disabled = true;
    opt.selected = true;
    opt.textContent = label;
    select.appendChild(opt);
  }

  if (!Array.isArray(users) || users.length === 0) {
    // No users: show fallback message in all dropdowns
    resetSelect(receivedSelect, 'No accounts found. Add users in Accounts.');
    resetSelect(assistedSelect, 'No accounts found. Add users in Accounts.');
    resetSelect(oicSelect, 'No accounts found. Add users in Accounts.');
    resetSelect(routedSelect, 'No accounts found. Add users in Accounts.');
    return;
  }

  // Names for Received By, Assisted By, OIC
  const names = users.map(u => u.name).filter(Boolean);
  // Emails for Routed To
  const emails = users.map(u => u.email).filter(Boolean);

  // Populate Received By
  resetSelect(receivedSelect, 'Received by');
  names.forEach(name => {
    const opt = document.createElement('option');
    opt.value = name;
    opt.textContent = name;
    receivedSelect.appendChild(opt);
  });

  // Populate Assisted By (add a blank/none option)
  resetSelect(assistedSelect, 'Assisted by');
  const noneOpt = document.createElement('option');
  noneOpt.value = '';
  noneOpt.textContent = '-----';
  assistedSelect.appendChild(noneOpt);
  names.forEach(name => {
    const opt = document.createElement('option');
    opt.value = name;
    opt.textContent = name;
    assistedSelect.appendChild(opt);
  });

  // Populate OIC
  resetSelect(oicSelect, 'Select OIC');
  names.forEach(name => {
    const opt = document.createElement('option');
    opt.value = name;
    opt.textContent = name;
    oicSelect.appendChild(opt);
  });

  // Populate Routed To (emails)
  resetSelect(routedSelect, 'Routed to');
  emails.forEach(email => {
    const opt = document.createElement('option');
    opt.value = email;
    opt.textContent = email;
    routedSelect.appendChild(opt);
  });
});
