document.addEventListener("DOMContentLoaded", () => {

  // ==========================
  // PREFILL WHEN EDITING
  // ==========================
  let editIndex = localStorage.getItem("editIndex");
  const editDocument = JSON.parse(localStorage.getItem("editDocument"));

  // Convert the string "null" to actual null if needed
  if (editIndex === "null" || editIndex === undefined) {
    editIndex = null;
  }

  // ✅ Prefill only if actually editing and we have a valid document
  if (editDocument && editIndex !== null) {
    // helper: try name first, then id
    const titleEl = document.querySelector('[name="title"], #title');
    if (titleEl) titleEl.value = editDocument.title || '';

    const projectTypeEl = document.querySelector("[name='projectType']");
    if (projectTypeEl) projectTypeEl.value = editDocument.projectType || '';

    const znEl = document.querySelector('[name="znApplication"], #znApplication');
    if (znEl) znEl.value = editDocument.znApp || '';

    const zoningEl = document.querySelector("[name='zoning']");
    if (zoningEl) zoningEl.value = editDocument.zoning || '';

    const dateOfAppEl = document.getElementById('dateOfApplication') || document.querySelector("[name='dateOfApplication']");
    if (dateOfAppEl) dateOfAppEl.value = editDocument.dateOfApp || '';

    const dueDateEl = document.getElementById('dueDate') || document.querySelector("[name='dueDate']");
    if (dueDateEl) dueDateEl.value = editDocument.dueDate || '';

    const receivedEl = document.getElementById('receivedSelect') || document.querySelector("[name='receivedBy']");
    if (receivedEl) receivedEl.value = editDocument.receivedBy || '';

    const assistedEl = document.getElementById('assistedSelect') || document.querySelector("[name='assistedBy']");
    if (assistedEl) assistedEl.value = editDocument.assistedBy || '';

    const applicantEl = document.querySelector("[name='applicantName']");
    if (applicantEl) applicantEl.value = editDocument.applicantName || '';

    const routedEl = document.getElementById('routedSelect') || document.querySelector("[name='routedTo']");
    if (routedEl) routedEl.value = editDocument.routedTo || '';

    const floorEl = document.querySelector("[name='floorArea']");
    if (floorEl) floorEl.value = editDocument.floorArea || '';

    // The saved document stores location as "Barangay, Purok" — parse it back into selects
    const barangayEl = document.getElementById('barangaySelect');
    const purokEl = document.getElementById('purokSelect');
    if (editDocument.location) {
      const parts = String(editDocument.location).split(',').map(s => s.trim());
      if (barangayEl) barangayEl.value = parts[0] || '';
      if (purokEl) purokEl.value = parts[1] || '';
    }

    const lotEl = document.querySelector("[name='lotArea']");
    if (lotEl) lotEl.value = editDocument.lotArea || '';

    const storeyEl = document.querySelector("[name='storey']");
    if (storeyEl) storeyEl.value = editDocument.storey || '';

    const landmarkEl = document.getElementById('landmark') || document.querySelector("[name='landmark']");
    if (landmarkEl) landmarkEl.value = editDocument.landmark || '';

    const mezanineEl = document.querySelector("[name='mezanine']");
    if (mezanineEl) mezanineEl.value = editDocument.mezanine || '';

    const oicEl = document.getElementById('oicSelect');
    if (oicEl) oicEl.value = editDocument.oic || '';
  } else {
    // 🧹 Force clear to avoid autofill next time
    localStorage.removeItem("editIndex");
    localStorage.removeItem("editDocument");
  }

  // ==========================
  // AUTO DATE + ZONING LOGIC
  // ==========================
  const dateApp = document.getElementById("dateOfApplication");
  const dueDate = document.getElementById("dueDate");
  const znField = document.querySelector('[name="znApplication"], #znApplication');
  const titleSelect = document.querySelector('[name="title"], #title');

  // 🗓️ Add 12 working days (Mon–Fri)
  function addWorkingDays(startDate, daysToAdd) {
    let current = new Date(startDate);
    let addedDays = 0;
    while (addedDays < daysToAdd) {
      current.setDate(current.getDate() + 1);
      const day = current.getDay();
      if (day !== 0 && day !== 6) addedDays++;
    }
    return current;
  }

  // 🗓️ Format as "Month DD, YYYY"
  function formatLongDate(date) {
    return date.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  }

  // 🧮 Auto fill date of application & due date
  const today = new Date();
  if (dateApp) dateApp.value = formatLongDate(today);
  if (dueDate) {
    const computedDue = addWorkingDays(today, 12);
    dueDate.value = formatLongDate(computedDue);
  }

  // Recalculate if date of application changes
  if (dateApp && dueDate) {
    dateApp.addEventListener("change", () => {
      const selected = new Date(dateApp.value);
      const newDue = addWorkingDays(selected, 12);
      dueDate.value = formatLongDate(newDue);
    });
  }

  // =============================
  // AUTO ZONING APPLICATION NO.
  // =============================
  function getPrefix(title) {
    if (title.includes("LC") || title.includes("Zoning") || title.includes("Development")) return "LC";
    return "XX";
  }

  function getNextSequence(prefix, year) {
    const key = `${prefix}-${year}-counter`;
    let counter = parseInt(localStorage.getItem(key)) || 0;
    counter++;
    localStorage.setItem(key, counter);
    return counter.toString().padStart(4, "0");
  }

  function generateZoningNumber(title) {
    const prefix = getPrefix(title);
    const year = new Date().getFullYear();
    const seq = getNextSequence(prefix, year);
    return `${prefix}-${year}-${seq}`;
  }

  if (titleSelect && znField) {
    titleSelect.addEventListener("change", () => {
      const title = titleSelect.value.trim();
      if (title) znField.value = generateZoningNumber(title);
    });
  }

  // =============================
  // SAVE DOCUMENT ON FORM SUBMIT
  // =============================
  const form = document.querySelector(".form");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    // Validate file presence: if creating a new document, require at least one attached file.
    const fileInput = document.getElementById('fileInput');
    const existingEditDoc = JSON.parse(localStorage.getItem('editDocument'));

    const hasFilesNow = fileInput && fileInput.files && fileInput.files.length > 0;
    const hasFilesBefore = existingEditDoc && Array.isArray(existingEditDoc.fileNames) && existingEditDoc.fileNames.length > 0;

    if (!hasFilesNow && !hasFilesBefore) {
      alert('⚠️ Please attach at least one file before saving.');
      return; // stop save
    }

    // Get file data from upload.js (Base64, type, name)
    let filesArr = [];
    let fileNamesArr = [];
    // Always try to get latestUploadFiles if present
    const latestUploadFiles = JSON.parse(localStorage.getItem('latestUploadFiles') || '[]');
    if (latestUploadFiles.length > 0) {
      filesArr = latestUploadFiles;
      fileNamesArr = latestUploadFiles.map(f => f.name);
    } else if (fileInput && fileInput.files && fileInput.files.length > 0) {
      // fallback: just names
      fileNamesArr = Array.from(fileInput.files).map(f => f.name);
    } else if (existingEditDoc && Array.isArray(existingEditDoc.files)) {
      filesArr = existingEditDoc.files;
      fileNamesArr = existingEditDoc.fileNames || [];
    } else if (existingEditDoc && Array.isArray(existingEditDoc.fileNames)) {
      fileNamesArr = existingEditDoc.fileNames;
    }

    const now = new Date();
    const newDoc = {
      dateAdded: now.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
      dateSort: now.toISOString(),
      title: document.getElementById("title").value,
      projectType: document.querySelector("[name='projectType']").value,
      znApp: document.querySelector("[name='znApplication']").value,
      zoning: document.querySelector("[name='zoning']").value,
      dateOfApp: document.getElementById("dateOfApplication").value,
      dueDate: document.getElementById("dueDate").value,
      receivedBy: document.getElementById("receivedSelect").value,
      assistedBy: document.getElementById("assistedSelect").value,
      applicantName: document.querySelector("[name='applicantName']").value,
      routedTo: document.getElementById("routedSelect").value,
      location:
        document.getElementById("barangaySelect").value +
        ", " +
        document.getElementById("purokSelect").value,
      floorArea: document.querySelector("[name='floorArea']").value,
      lotArea: document.querySelector("[name='lotArea']").value,
      storey: document.querySelector("[name='storey']").value,
      mezanine: document.querySelector("[name='mezanine']").value,
      oic: document.getElementById("oicSelect").value,
      fileNames: fileNamesArr,
      files: filesArr,
    };

    // ✅ SAVE to localStorage
    let docs = JSON.parse(localStorage.getItem("documents")) || [];

    if (editIndex !== null) {
      // Update existing document
      docs[editIndex] = newDoc;
      localStorage.removeItem("editIndex");
      localStorage.removeItem("editDocument");
    } else {
      // Add new document
      docs.push(newDoc);
    }

  localStorage.setItem("documents", JSON.stringify(docs));
  // Clear latestUploadFiles after saving
  localStorage.removeItem('latestUploadFiles');
  alert("✅ Document successfully saved!");
  window.location.href = "documents.html";
  });
});
