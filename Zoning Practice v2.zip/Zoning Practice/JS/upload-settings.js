document.addEventListener("DOMContentLoaded", () => {
  const updateButton = document.querySelector(".btn--primary");

  if (!updateButton) return;

  updateButton.addEventListener("click", (event) => {
    event.preventDefault();

    // Create overlay
    const overlay = document.createElement("div");
    overlay.classList.add("overlay");

    // Create modal
    const modal = document.createElement("div");
    modal.classList.add("modal");
    modal.innerHTML = `
      <div class="modal__content">
        <div class="loader"></div>
        <p id="modalText">Updating Settings...</p>
      </div>
    `;

    // Add both to DOM
    document.body.appendChild(overlay);
    document.body.appendChild(modal);

    // Simulate loading (2 seconds)
    setTimeout(() => {
      modal.innerHTML = `
        <div class="modal__content success-popup">
          <div class="success-icon">✅</div>
          <h2>Settings Updated Successfully!</h2>
          <p>Your preferences have been saved.</p>
          <button id="okButton" class="btn btn--success">OK</button>
          <small class="popup-tip">You can also press any key to return to Settings</small>
        </div>
      `;

      const okButton = document.getElementById("okButton");
      okButton.addEventListener("click", () => {
        window.location.href = "settings.html";
      });

      // Allow any key press to redirect
      document.addEventListener("keydown", () => {
        window.location.href = "settings.html";
      });
    }, 2000);
  });
});
