// === Create User Logic with Modal & Redirect ===
document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector(".form");
  const modal = document.getElementById("successModal");
  const modalText = document.getElementById("modalText");
  const okButton = document.getElementById("okButton");
  const loader = document.querySelector(".loader");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    // Show modal with loader
    modal.classList.remove("hidden");
    modalText.textContent = "Creating User...";
    okButton.classList.add("hidden");
    loader.style.display = "block";

    // Simulate user creation delay
    setTimeout(() => {
      loader.style.display = "none";
      modalText.textContent = "✅ User Created Successfully!";
      okButton.classList.remove("hidden");

      // Allow pressing any key to confirm
      document.addEventListener("keydown", redirectToDashboard);
    }, 2000);
  });

  // Click OK to redirect
  okButton.addEventListener("click", redirectToDashboard);

  // Redirect function
  function redirectToDashboard() {
    window.location.href = "accounts.html";
  }
});
