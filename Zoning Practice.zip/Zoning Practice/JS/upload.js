document.addEventListener("DOMContentLoaded", () => {
  const uploadArea = document.getElementById("uploadArea");
  const fileInput = document.getElementById("fileInput");
  const fileNameDisplay = document.getElementById("fileName");
  const saveButton = document.querySelector(".btn--success[type='submit']");
  const uploadButton = document.querySelector("label[for='fileInput']");
  let selectedFiles = [];

  // ✅ Allow multiple file selection
  fileInput.setAttribute("multiple", "true");

  // === DRAG & DROP FEATURE ===
  uploadArea.addEventListener("dragover", (e) => {
    e.preventDefault();
    uploadArea.classList.add("dragover");
  });

  uploadArea.addEventListener("dragleave", () => {
    uploadArea.classList.remove("dragover");
  });

  uploadArea.addEventListener("drop", (e) => {
    e.preventDefault();
    uploadArea.classList.remove("dragover");

    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      selectedFiles = files;
      displaySelectedFiles();
      const dataTransfer = new DataTransfer();
      files.forEach((f) => dataTransfer.items.add(f));
      fileInput.files = dataTransfer.files;
    }
  });

  // === UPLOAD BUTTON ===
  uploadButton.addEventListener("click", (e) => {
    e.preventDefault();
    fileInput.click();
  });

  // === FILE SELECTION ===
  fileInput.addEventListener("change", () => {
    const files = Array.from(fileInput.files);
    if (files.length > 0) {
      selectedFiles = files;
      displaySelectedFiles();
    } else {
      selectedFiles = [];
      resetFileDisplay();
    }
  });

  function displaySelectedFiles() {
    if (selectedFiles.length === 1) {
      fileNameDisplay.textContent = `📄 ${selectedFiles[0].name}`;
    } else {
      fileNameDisplay.innerHTML =
        "📂 " +
        selectedFiles.length +
        " files selected:<br>" +
        selectedFiles.map((f) => `• ${f.name}`).join("<br>");
    }
    fileNameDisplay.style.color = "#16a34a";
  }

  function resetFileDisplay() {
    fileNameDisplay.textContent = "No file attached";
    fileNameDisplay.style.color = "#555";
  }

  // === MODAL ===
  const modal = document.createElement("div");
  modal.classList.add("modal");
  modal.innerHTML = `
    <div class="modal-content">
      <div class="loader" id="uploadLoader"></div>
      <h3 id="uploadMessage">Uploading Document(s)...</h3>
    </div>
  `;
  document.body.appendChild(modal);

  // === SAVE DOCUMENT ===
  saveButton.addEventListener("click", (e) => {
    e.preventDefault();

    // 🚫 No files selected — stop everything
    if (selectedFiles.length === 0 || fileInput.files.length === 0) {
      alert("⚠️ Please attach at least one file before saving.");
      resetFileDisplay();
      return; // ❌ stop upload simulation
    }

    // ✅ Show modal
    modal.style.display = "flex";
    const loader = document.getElementById("uploadLoader");
    const message = document.getElementById("uploadMessage");

    loader.style.display = "block";
    message.textContent = `Uploading ${selectedFiles.length} file(s)...`;

    // Simulate upload delay
    setTimeout(() => {
      loader.style.display = "none";
      message.innerHTML = `
        ✅ <strong>${selectedFiles.length} file(s) uploaded successfully!</strong><br><br>
        <button id="okButton" class="btn btn--success">OK</button><br><br>
        <small>Tip: Press any key to go to Dashboard</small>
      `;

      const okButton = document.getElementById("okButton");
      okButton.addEventListener("click", () => {
        window.location.href = "dashboard.html";
      });

      document.addEventListener("keydown", () => {
        window.location.href = "dashboard.html";
      });
    }, 2000);
  });

  // === HINT MESSAGE ===
  const hint = document.createElement("p");
  hint.classList.add("muted");
  hint.style.marginTop = "8px";
  hint.textContent =
    "💡 You can click Upload or drag multiple files into the box.";
  uploadArea.appendChild(hint);
});

document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector(".form");
  const fileInput = document.getElementById("fileInput");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    if (!fileInput.files || fileInput.files.length === 0) {
      alert("⚠️ Please attach at least one file before submitting.");
      return;
    }

    // 🧾 Collect form data
    const newDocument = {
      title: form.querySelector("[name='documentTitle']").value,
      lcApp: form.querySelector("[name='lcApplication']").value,
      projectType: form.querySelector("[name='projectType']").value,
      routedTo: form.querySelector("[name='routedTo']").value,
      location: form.querySelector("[name='location']").value,
      receivedBy: form.querySelector("[name='receivedBy']").value,
      applicantName: form.querySelector("[name='applicantName']").value,
      oic: document.getElementById("oicSelect").value,
      dateOfApp: form.querySelector("[name='dateOfApplication']").value,
      dueDate: form.querySelector("[name='dueDate']").value,
      floorArea: form.querySelector("[name='floorArea']").value,
      lotArea: form.querySelector("[name='lotArea']").value,
      storey: form.querySelector("[name='storey']").value,
      fileNames: Array.from(fileInput.files).map((f) => f.name),
      dateCreated: new Date().toLocaleString(),
      dateAdded: new Date().toLocaleString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
    };

    // Save to localStorage
    let documents = JSON.parse(localStorage.getItem("documents")) || [];
    documents.push(newDocument);
    localStorage.setItem("documents", JSON.stringify(documents));

    // Redirect or show success modal
    window.location.href = "documents.html";
  });


    // 🗃️ Save to localStorage
    const savedDocs = JSON.parse(localStorage.getItem("documents")) || [];
    if (editIndex !== null) {
    savedDocs[editIndex] = newDoc;
    localStorage.removeItem("editIndex");
    localStorage.removeItem("editDocument");
  } else {
    savedDocs.push(newDoc);
  }
    localStorage.setItem("documents", JSON.stringify(savedDocs));

    alert("✅ Document saved successfully!");
    window.location.href = "documents.html";
  });


