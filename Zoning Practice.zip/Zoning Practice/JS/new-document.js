let editIndex = localStorage.getItem("editIndex");
const editDocument = JSON.parse(localStorage.getItem("editDocument"));

// Convert the string "null" to actual null if needed
if (editIndex === "null" || editIndex === undefined) {
  editIndex = null;
}

// ✅ Prefill only if actually editing and we have a valid document
if (editDocument && editIndex !== null) {
  document.querySelector("[name='documentTitle']").value = editDocument.title;
  document.querySelector("[name='lcApplication']").value = editDocument.lcApp;
  document.querySelector("[name='projectType']").value = editDocument.projectType;
  document.querySelector("[name='routedTo']").value = editDocument.routedTo;
  document.querySelector("[name='location']").value = editDocument.location;
  document.querySelector("[name='receivedBy']").value = editDocument.receivedBy;
  document.querySelector("[name='applicantName']").value = editDocument.applicantName;
  document.getElementById("oicSelect").value = editDocument.oic;
  document.querySelector("[name='floorArea']").value = editDocument.floorArea;
  document.querySelector("[name='dueDate']").value = editDocument.dueDate;
  document.querySelector("[name='lotArea']").value = editDocument.lotArea;
  document.querySelector("[name='dateOfApplication']").value = editDocument.dateOfApp;
  document.querySelector("[name='storey']").value = editDocument.storey;
} else {
  // 🧹 Force clear to avoid autofill next time
  localStorage.removeItem("editIndex");
  localStorage.removeItem("editDocument");
}

  
document.addEventListener("DOMContentLoaded", () => {
  const dateOfApplication = document.getElementById("dateOfApplication");
  const dueDate = document.getElementById("dueDate");
  const dueTime = document.getElementById("dueTime");

  // 🧮 Function to add 12 working days (Mon–Fri only)
  function addWorkingDays(startDate, numDays) {
    let result = new Date(startDate);
    let addedDays = 0;

    while (addedDays < numDays) {
      result.setDate(result.getDate() + 1);
      const day = result.getDay();
      if (day !== 0 && day !== 6) { // skip Sunday (0) and Saturday (6)
        addedDays++;
      }
    }
    return result;
  }

  // 🗓️ Format date as "Month DD, YYYY"
  function formatReadableDate(dateObj) {
    const options = { year: "numeric", month: "long", day: "numeric" };
    return dateObj.toLocaleDateString("en-US", options);
  }

  // 🔁 When "Date of Application" changes
  dateOfApplication.addEventListener("change", () => {
    if (!dateOfApplication.value) {
      dueDate.value = "";
      dueTime.value = "";
      dueTime.disabled = true;
      return;
    }

    const startDate = new Date(dateOfApplication.value);
    const calculatedDueDate = addWorkingDays(startDate, 12);

    // ✅ Format as readable (e.g. November 12, 2025)
    const formattedDate = formatReadableDate(calculatedDueDate);
    dueDate.value = formattedDate;

    // Enable time input
    dueTime.disabled = false;
  });

  // 🕒 Disable time if no due date
  dueDate.addEventListener("input", () => {
    if (dueDate.value) {
      dueTime.disabled = false;
    } else {
      dueTime.disabled = true;
      dueTime.value = "";
    }
  });
});

