  document.addEventListener("DOMContentLoaded", () => {
  const tableBody = document.getElementById("documentTableBody");
  const searchInput = document.getElementById("searchInput");
  let savedDocs = JSON.parse(localStorage.getItem("documents")) || [];

  function renderTable(filteredDocs = savedDocs) {
    tableBody.innerHTML = "";

    if (filteredDocs.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="15" style="text-align:center; color:gray;">No documents found</td></tr>`;
      return;
    }

    filteredDocs.forEach((doc, index) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${doc.dateAdded || "—"}</td>
        <td>${doc.title}</td>
        <td>${doc.lcApp}</td>
        <td>${doc.projectType}</td>
        <td>${doc.routedTo}</td>
        <td>${doc.location}</td>
        <td>${doc.receivedBy}</td>
        <td>${doc.applicantName}</td>
        <td>${doc.oic}</td>
        <td>${doc.floorArea}</td>
        <td>${doc.dueDate}</td>
        <td>${doc.lotArea}</td>
        <td>${doc.dateOfApp}</td>
        <td>${doc.storey}</td>
        <td>
          <button class="btn btn--small btn--primary edit-btn" data-index="${index}">✏️ Edit</button>
          <button class="btn btn--small btn--danger delete-btn" data-index="${index}">🗑️ Delete</button>
        </td>
      `;
      tableBody.appendChild(row);
    });

    document.querySelectorAll(".delete-btn").forEach(btn => btn.addEventListener("click", handleDelete));
    document.querySelectorAll(".edit-btn").forEach(btn => btn.addEventListener("click", handleEdit));
  }

  function handleDelete(e) {
    const index = e.target.dataset.index;
    if (confirm("Are you sure you want to delete this document?")) {
      savedDocs.splice(index, 1);
      localStorage.setItem("documents", JSON.stringify(savedDocs));
      renderTable();
    }
  }

  function handleEdit(e) {
    const index = e.target.dataset.index;
    const doc = savedDocs[index];
    localStorage.setItem("editIndex", index);
    localStorage.setItem("editDocument", JSON.stringify(doc));
    window.location.href = "new-document.html";
  }

  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase().trim();
    const filteredDocs = savedDocs.filter(doc =>
      Object.values(doc).some(value =>
        String(value).toLowerCase().includes(query)
      )
    );
    renderTable(filteredDocs);
  });

  renderTable();
});

