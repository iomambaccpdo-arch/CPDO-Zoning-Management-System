    document.addEventListener("DOMContentLoaded", () => {
      const modal = document.getElementById("editModal");
      const form = document.getElementById("editForm");
      const cancelBtn = document.getElementById("cancelEdit");
      const successPopup = document.getElementById("successPopup");

      const nameInput = document.getElementById("editName");
      const usernameInput = document.getElementById("editUsername");
      const emailInput = document.getElementById("editEmail");
      const passwordInput = document.getElementById("editPassword");
      const roleInput = document.getElementById("editRole");
      let currentRow = null;

      // --- Edit Button ---
      document.querySelectorAll(".edit-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
          currentRow = e.target.closest("tr");
          const cells = currentRow.querySelectorAll("td");

          document.getElementById("editUserId").value = cells[0].textContent;
          nameInput.value = cells[1].textContent;
          usernameInput.value = cells[2].textContent;
          emailInput.value = cells[3].textContent;
          roleInput.value = cells[4].textContent;

          modal.style.display = "flex";
        });
      });

      // --- Cancel Edit ---
      cancelBtn.addEventListener("click", () => {
        modal.style.display = "none";
        form.reset();
      });

      // --- Save Changes ---
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        if (currentRow) {
          const cells = currentRow.querySelectorAll("td");
          cells[1].textContent = nameInput.value;
          cells[2].textContent = usernameInput.value;
          cells[3].textContent = emailInput.value;
          cells[4].textContent = roleInput.value;
          modal.style.display = "none";
          form.reset();

          // ✅ Show success popup
          successPopup.style.display = "block";
          setTimeout(() => {
            successPopup.style.display = "none";
          }, 2500);
        }
      });

      // --- Delete Button ---
      document.querySelectorAll(".delete-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
          const row = e.target.closest("tr");
          const name = row.children[1].textContent;
          if (confirm(`Are you sure you want to delete user "${name}"?`)) {
            row.remove();
          }
        });
      });

      // --- Close modal when clicking outside ---
      window.addEventListener("click", (e) => {
        if (e.target === modal) {
          modal.style.display = "none";
        }
      });
    });