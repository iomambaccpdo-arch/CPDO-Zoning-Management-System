// Authentication utility functions

// Check if user is logged in
function isLoggedIn() {
  const currentUser = localStorage.getItem('currentUser') || sessionStorage.getItem('currentUser');
  return currentUser !== null;
}

// Get current user
function getCurrentUser() {
  const currentUser = localStorage.getItem('currentUser') || sessionStorage.getItem('currentUser');
  return currentUser ? JSON.parse(currentUser) : null;
}

// Logout function
function logout() {
  localStorage.removeItem('currentUser');
  sessionStorage.removeItem('currentUser');
  window.location.href = 'login.html';
}

// Protect pages - redirect to login if not authenticated
function protectPage() {
  if (!isLoggedIn()) {
    window.location.href = 'login.html';
  }
}

// Initialize sign out buttons
function initSignOut() {
  const signOutButtons = document.querySelectorAll('a[href="#"]');
  signOutButtons.forEach(button => {
    if (button.textContent.trim() === 'Sign out' || button.textContent.includes('Sign out')) {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        logout();
      });
    }
  });
}

// Update user card with current user info
function updateUserCard() {
  const user = getCurrentUser();
  if (user) {
    // Update name
    const nameElements = document.querySelectorAll('.usercard__name');
    nameElements.forEach(el => {
      // Use stored name, fallback to username, then default to 'User'
      const displayName = user.name || user.username || 'User';
      el.textContent = displayName;
    });
    
    // Update role (show role like Admin, User, Viewer, or designation)
    const roleElements = document.querySelectorAll('.usercard__role');
    roleElements.forEach(el => {
      // Show role first, fallback to designation, then default to 'User'
      el.textContent = user.role || user.designation || 'User';
    });
    
    // Update email
    const emailElements = document.querySelectorAll('.usercard__email');
    emailElements.forEach(el => {
      el.textContent = user.email || '';
    });
  } else {
    // If no user found, clear the fields
    document.querySelectorAll('.usercard__name').forEach(el => el.textContent = '');
    document.querySelectorAll('.usercard__role').forEach(el => el.textContent = '');
    document.querySelectorAll('.usercard__email').forEach(el => el.textContent = '');
  }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  initSignOut();
  updateUserCard();
});

